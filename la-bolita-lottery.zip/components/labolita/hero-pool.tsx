'use client'

import { useEffect, useState } from 'react'
import { Clock, Flame } from 'lucide-react'

type HeroPoolProps = {
  drawName: string
  poolValue: number
  /** Seconds remaining until closure */
  initialSeconds: number
}

function format(seconds: number): string {
  const s = Math.max(0, seconds)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return [h, m, sec].map((v) => v.toString().padStart(2, '0')).join(':')
}

export function HeroPool({ drawName, poolValue, initialSeconds }: HeroPoolProps) {
  const [remaining, setRemaining] = useState(initialSeconds)

  useEffect(() => {
    const id = setInterval(() => {
      setRemaining((prev) => (prev <= 0 ? 0 : prev - 1))
    }, 1000)
    return () => clearInterval(id)
  }, [])

  const closing = remaining <= 60
  const closed = remaining <= 0

  return (
    <section className="mx-auto max-w-md px-4 pt-4">
      <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-5 glow-gold">
        <div
          className="pointer-events-none absolute -right-10 -top-10 size-40 rounded-full bg-accent/10 blur-2xl"
          aria-hidden="true"
        />

        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-accent/15 px-2.5 py-1 text-xs font-semibold text-accent">
            <Flame className="size-3.5" aria-hidden="true" />
            {drawName}
          </span>
          <span className="text-xs font-medium text-muted-foreground">
            Sorteo activo
          </span>
        </div>

        <div className="mt-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">
            Pozo total
          </p>
          <p className="mt-1 font-mono text-4xl font-bold tabular-nums text-accent text-glow-gold">
            ${poolValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            <span className="ml-1.5 align-middle text-base font-medium text-muted-foreground">
              USDT
            </span>
          </p>
        </div>

        <div className="mt-4 flex items-center justify-between rounded-xl border border-border bg-background/60 px-4 py-3">
          <span
            className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
              closing ? 'text-danger' : 'text-muted-foreground'
            }`}
          >
            <Clock
              className={`size-4 ${closing ? 'animate-pulse-ring' : ''}`}
              aria-hidden="true"
            />
            {closed ? 'CERRADO' : 'CIERRE EN'}
          </span>
          <span
            className={`font-mono text-2xl font-bold tabular-nums ${
              closing ? 'text-danger text-glow-danger' : 'text-foreground'
            }`}
            aria-live="polite"
          >
            {format(remaining)}
          </span>
        </div>
      </div>
    </section>
  )
}
