'use client'

import { useState } from 'react'
import { Search, Sparkles } from 'lucide-react'
import { CHARADA, normalizeKeyword } from '@/lib/labolita'

type CharadaSearchProps = {
  onMatch: (num: string, keyword: string) => void
}

export function CharadaSearch({ onMatch }: CharadaSearchProps) {
  const [value, setValue] = useState('')
  const [notFound, setNotFound] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const key = normalizeKeyword(value)
    const num = CHARADA[key]
    if (num) {
      setNotFound(false)
      onMatch(num, value.trim())
    } else {
      setNotFound(true)
    }
  }

  return (
    <section className="mx-auto max-w-md px-4 pt-4">
      <form onSubmit={handleSubmit} className="relative">
        <label htmlFor="charada" className="sr-only">
          Escribe tu sueño para buscar en la charada
        </label>
        <Sparkles
          className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-accent"
          aria-hidden="true"
        />
        <input
          id="charada"
          type="text"
          inputMode="text"
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setNotFound(false)
          }}
          onKeyDown={(e) => {
            if (
              e.key === 'Enter' &&
              (e.nativeEvent.isComposing || e.keyCode === 229)
            ) {
              e.preventDefault()
            }
          }}
          placeholder="Escribe tu sueño… (agua, perro, gato)"
          className="w-full rounded-xl border border-border bg-card py-3 pl-10 pr-24 text-sm text-foreground placeholder:text-muted-foreground focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon"
        />
        <button
          type="submit"
          className="absolute right-1.5 top-1/2 inline-flex -translate-y-1/2 items-center gap-1.5 rounded-lg bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-secondary/70 active:scale-95"
        >
          <Search className="size-3.5" aria-hidden="true" />
          Buscar
        </button>
      </form>
      {notFound && (
        <p className="mt-1.5 px-1 text-xs text-danger" role="alert">
          No encontramos ese sueño en la charada. Prueba otra palabra.
        </p>
      )}
    </section>
  )
}
