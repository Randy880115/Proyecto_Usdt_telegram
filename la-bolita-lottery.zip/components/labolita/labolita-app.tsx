'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Check, X } from 'lucide-react'
import { NUMBERS } from '@/lib/labolita'
import { getWebApp, haptic, notify } from '@/lib/telegram'
import { Header } from './header'
import { HeroPool } from './hero-pool'
import { CharadaSearch } from './charada-search'
import { NumberGrid } from './number-grid'
import { RecentResults } from './recent-results'
import { BetBar } from './bet-bar'

type Toast = { kind: 'success' | 'error'; text: string } | null

export function LaBolitaApp() {
  const [username, setUsername] = useState('jugador')
  const [balance, setBalance] = useState(50)
  const [selected, setSelected] = useState<string | null>(null)
  const [focusNumber, setFocusNumber] = useState<string | null>(null)
  const [amount, setAmount] = useState('5')
  const [toast, setToast] = useState<Toast>(null)

  // Telegram WebApp init.
  useEffect(() => {
    const wa = getWebApp()
    if (!wa) return
    wa.ready()
    wa.expand()
    wa.setHeaderColor?.('#0f172a')
    wa.setBackgroundColor?.('#0f172a')
    const tgUser = wa.initDataUnsafe?.user
    if (tgUser?.username) {
      setUsername(tgUser.username)
    } else if (tgUser?.first_name) {
      setUsername(tgUser.first_name.toLowerCase())
    }
  }, [])

  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(null), 2600)
    return () => clearTimeout(id)
  }, [toast])

  const multiplier = useMemo(() => {
    if (!selected) return null
    return NUMBERS.find((x) => x.n === selected)?.mult ?? null
  }, [selected])

  const handleSelect = useCallback((num: string) => {
    haptic('medium')
    setSelected((prev) => (prev === num ? null : num))
  }, [])

  const handleCharadaMatch = useCallback((num: string, keyword: string) => {
    haptic('light')
    setSelected(num)
    // Retrigger scroll/flash even if the same number is matched again.
    setFocusNumber(null)
    requestAnimationFrame(() => setFocusNumber(num))
    setToast({ kind: 'success', text: `"${keyword}" → número ${num}` })
  }, [])

  const handleDeposit = useCallback(() => {
    haptic('light')
    // Demo top-up; a real app would open an invoice / on-ramp.
    setBalance((b) => b + 25)
    setToast({ kind: 'success', text: 'Depósito demo: +$25.00 USDT' })
  }, [])

  const handleBet = useCallback(() => {
    const amt = Number.parseFloat(amount)
    if (!selected || !Number.isFinite(amt) || amt <= 0) return
    if (amt > balance) {
      notify('error')
      setToast({ kind: 'error', text: 'Saldo USDT insuficiente' })
      return
    }

    const payload = {
      action: 'APOSTAR',
      number: selected,
      amount: amt,
    }

    const wa = getWebApp()
    if (wa) {
      notify('success')
      wa.sendData(JSON.stringify(payload))
    } else {
      // Preview fallback outside Telegram.
      haptic('heavy')
      // eslint-disable-next-line no-console
      console.log('[v0] APOSTAR payload:', payload)
    }

    setBalance((b) => Math.round((b - amt) * 100) / 100)
    setToast({
      kind: 'success',
      text: `Apuesta enviada: $${amt.toFixed(2)} al ${selected}`,
    })
    setSelected(null)
  }, [amount, selected, balance])

  return (
    <div className="relative min-h-dvh pb-2">
      <Header username={username} balance={balance} onDeposit={handleDeposit} />

      <main>
        <HeroPool
          drawName="Florida Noche"
          poolValue={1480}
          initialSeconds={14 * 60 + 22}
        />
        <CharadaSearch onMatch={handleCharadaMatch} />
        <NumberGrid
          selected={selected}
          focusNumber={focusNumber}
          onSelect={handleSelect}
        />
        <RecentResults />
      </main>

      <BetBar
        selected={selected}
        multiplier={multiplier}
        amount={amount}
        onAmountChange={setAmount}
        onBet={handleBet}
      />

      {toast && (
        <div
          role="status"
          className="fixed inset-x-0 bottom-28 z-40 mx-auto flex max-w-md justify-center px-4"
        >
          <div
            className={`flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-semibold shadow-lg backdrop-blur-md ${
              toast.kind === 'success'
                ? 'border-neon/40 bg-card/90 text-neon'
                : 'border-danger/40 bg-card/90 text-danger'
            }`}
          >
            {toast.kind === 'success' ? (
              <Check className="size-4" aria-hidden="true" />
            ) : (
              <X className="size-4" aria-hidden="true" />
            )}
            {toast.text}
          </div>
        </div>
      )}
    </div>
  )
}
