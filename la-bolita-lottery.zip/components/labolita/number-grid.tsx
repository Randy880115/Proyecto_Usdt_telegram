'use client'

import { useEffect, useRef } from 'react'
import { NUMBERS } from '@/lib/labolita'

type NumberGridProps = {
  selected: string | null
  focusNumber: string | null
  onSelect: (num: string) => void
}

export function NumberGrid({ selected, focusNumber, onSelect }: NumberGridProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const cellRefs = useRef<Record<string, HTMLButtonElement | null>>({})

  // Scroll to and flash the charada match.
  useEffect(() => {
    if (!focusNumber) return
    const el = cellRefs.current[focusNumber]
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      el.classList.remove('animate-flash')
      // force reflow so the animation can retrigger
      void el.offsetWidth
      el.classList.add('animate-flash')
    }
  }, [focusNumber])

  return (
    <section className="mx-auto max-w-md px-4 pt-4">
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="text-sm font-semibold">Elige tu número</h2>
        <span className="text-xs text-muted-foreground">01 – 100</span>
      </div>

      <div
        ref={containerRef}
        className="grid-scroll grid max-h-[280px] grid-cols-5 gap-2 overflow-y-auto rounded-2xl border border-border bg-card/50 p-2.5"
      >
        {NUMBERS.map(({ n, mult }) => {
          const isActive = selected === n
          const jackpot = mult >= 100
          return (
            <button
              key={n}
              type="button"
              ref={(el) => {
                cellRefs.current[n] = el
              }}
              onClick={() => onSelect(n)}
              aria-pressed={isActive}
              aria-label={`Número ${n}, multiplicador ${mult}x`}
              className={`flex flex-col items-center justify-center rounded-xl border py-2.5 transition-all active:scale-95 ${
                isActive
                  ? 'border-neon bg-neon/15 glow-neon'
                  : 'border-border bg-background/60 hover:border-neon/40'
              }`}
            >
              <span
                className={`font-mono text-lg font-bold tabular-nums ${
                  isActive ? 'text-neon text-glow-neon' : 'text-foreground'
                }`}
              >
                {n}
              </span>
              <span
                className={`mt-0.5 text-[10px] font-semibold tabular-nums ${
                  jackpot ? 'text-accent' : 'text-muted-foreground'
                }`}
              >
                {mult.toFixed(1)}x
              </span>
            </button>
          )
        })}
      </div>
    </section>
  )
}
