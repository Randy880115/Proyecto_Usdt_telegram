'use client'

import { Plus, Wallet } from 'lucide-react'

type HeaderProps = {
  username: string
  balance: number
  onDeposit: () => void
}

export function Header({ username, balance, onDeposit }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex size-9 items-center justify-center rounded-full bg-secondary text-sm font-bold text-neon">
            {username.slice(0, 2).toUpperCase()}
          </div>
          <div className="leading-tight">
            <p className="text-xs text-muted-foreground">Bienvenido</p>
            <p className="text-sm font-semibold">@{username}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5">
            <Wallet className="size-4 text-neon" aria-hidden="true" />
            <span className="font-mono text-sm font-semibold tabular-nums">
              ${balance.toFixed(2)}
            </span>
            <span className="text-[10px] font-medium text-muted-foreground">
              USDT
            </span>
          </div>
          <button
            type="button"
            onClick={onDeposit}
            aria-label="Depositar USDT"
            className="flex size-9 items-center justify-center rounded-lg bg-neon text-neon-foreground transition-transform active:scale-90 glow-neon"
          >
            <Plus className="size-5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </header>
  )
}
