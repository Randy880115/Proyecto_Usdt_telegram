'use client'

import { Trophy } from 'lucide-react'
import { RECENT_RESULTS } from '@/lib/labolita'

export function RecentResults() {
  return (
    <section className="mx-auto max-w-md px-4 pt-6">
      <div className="mb-2 flex items-center gap-1.5 px-1">
        <Trophy className="size-4 text-accent" aria-hidden="true" />
        <h2 className="text-sm font-semibold">Resultados recientes</h2>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">Fecha</th>
              <th className="px-4 py-2.5 font-medium">Sorteo</th>
              <th className="px-4 py-2.5 text-center font-medium">Pick 3</th>
              <th className="px-4 py-2.5 text-right font-medium">Bolita</th>
            </tr>
          </thead>
          <tbody>
            {RECENT_RESULTS.map((r, i) => (
              <tr
                key={`${r.date}-${r.draw}-${i}`}
                className="border-b border-border/60 last:border-0"
              >
                <td className="px-4 py-2.5 text-xs text-muted-foreground">
                  {r.date}
                </td>
                <td className="px-4 py-2.5 text-xs">{r.draw}</td>
                <td className="px-4 py-2.5 text-center font-mono tabular-nums text-muted-foreground">
                  {r.pick3}
                </td>
                <td className="px-4 py-2.5 text-right">
                  <span className="inline-flex items-center justify-center rounded-md bg-neon/15 px-2 py-0.5 font-mono text-sm font-bold tabular-nums text-neon">
                    {r.bolita}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
