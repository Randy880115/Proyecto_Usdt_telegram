'use client'

import { Dice5 } from 'lucide-react'

type BetBarProps = {
  selected: string | null
  multiplier: number | null
  amount: string
  onAmountChange: (v: string) => void
  onBet: () => void
}

const QUICK = [1, 5, 10, 25]

export function BetBar({
  selected,
  multiplier,
  amount,
  onAmountChange,
  onBet,
}: BetBarProps) {
  const numAmount = Number.parseFloat(amount)
  const validAmount = Number.isFinite(numAmount) && numAmount > 0
  const canBet = selected !== null && validAmount
  const potential =
    canBet && multiplier ? (numAmount * multiplier).toFixed(2) : null

  return (
    <div className="sticky bottom-0 z-30 border-t border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto max-w-md px-4 pb-5 pt-3">
        <div className="mb-2.5 flex items-center justify-between text-xs">
          <span className="text-muted-foreground">
            {selected ? (
              <>
                Número{' '}
                <span className="font-mono font-bold text-neon">{selected}</span>
                {multiplier ? (
                  <span className="text-accent"> · {multiplier.toFixed(1)}x</span>
                ) : null}
              </>
            ) : (
              'Selecciona un número del tablero'
            )}
          </span>
          {potential && (
            <span className="text-muted-foreground">
              Ganas:{' '}
              <span className="font-mono font-semibold text-accent">
                ${potential}
              </span>
            </span>
          )}
        </div>

        <div className="mb-2.5 flex gap-2">
          {QUICK.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => onAmountChange(String(q))}
              className="flex-1 rounded-lg border border-border bg-card py-1.5 text-xs font-semibold text-foreground transition-colors hover:border-neon/50 active:scale-95"
            >
              ${q}
            </button>
          ))}
        </div>

        <div className="flex gap-2.5">
          <div className="relative flex-1">
            <label htmlFor="bet-amount" className="sr-only">
              Monto de la apuesta en USDT
            </label>
            <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted-foreground">
              $
            </span>
            <input
              id="bet-amount"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.5"
              value={amount}
              onChange={(e) => onAmountChange(e.target.value)}
              placeholder="0.00"
              className="w-full rounded-xl border border-border bg-card py-3.5 pl-7 pr-14 font-mono text-base font-semibold text-foreground placeholder:text-muted-foreground focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon"
            />
            <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[10px] font-medium text-muted-foreground">
              USDT
            </span>
          </div>

          <button
            type="button"
            onClick={onBet}
            disabled={!canBet}
            className={`flex items-center gap-2 rounded-xl px-6 py-3.5 text-base font-bold transition-all active:scale-95 ${
              canBet
                ? 'bg-neon text-neon-foreground glow-neon'
                : 'cursor-not-allowed bg-secondary text-muted-foreground'
            }`}
          >
            <Dice5 className="size-5" aria-hidden="true" />
            APOSTAR
          </button>
        </div>
      </div>
    </div>
  )
}
