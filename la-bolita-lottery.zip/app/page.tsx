import { LaBolitaApp } from '@/components/labolita/labolita-app'

export default function Page() {
  return <LaBolitaApp />
}
