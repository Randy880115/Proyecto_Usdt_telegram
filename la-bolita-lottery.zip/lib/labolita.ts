// Domain data for the La Bolita mini app.

export type BolitaNumber = {
  /** Bolita number string, "01" .. "100" */
  n: string
  /** Payout multiplier */
  mult: number
}

// Deterministic pseudo-random multiplier so the grid is stable across renders.
// Rarely-picked numbers pay big, popular ones pay small.
function multiplierFor(i: number): number {
  const seed = (Math.sin(i * 12.9898) * 43758.5453) % 1
  const r = Math.abs(seed)
  if (r > 0.9) return Math.round((400 + r * 300) * 10) / 10 // jackpot longshots
  if (r > 0.65) return Math.round((40 + r * 120) * 10) / 10
  if (r > 0.35) return Math.round((8 + r * 24) * 10) / 10
  return Math.round((1.8 + r * 4) * 10) / 10
}

export const NUMBERS: BolitaNumber[] = Array.from({ length: 100 }, (_, i) => {
  const value = i + 1 // 1 .. 100
  return {
    n: value === 100 ? '100' : value.toString().padStart(2, '0'),
    mult: multiplierFor(value),
  }
})

// La Charada Cubana: sueño / palabra -> número de la bolita.
export const CHARADA: Record<string, string> = {
  caballo: '01',
  mariposa: '02',
  marinero: '03',
  gato: '04',
  monja: '05',
  jicotea: '06',
  caracol: '07',
  muerto: '08',
  elefante: '09',
  pescado: '10',
  gallo: '11',
  ramera: '12',
  puta: '12',
  pavoreal: '13',
  tigre: '14',
  perro: '15',
  toro: '16',
  luna: '17',
  agua: '23',
  vapor: '23',
  paloma: '24',
  piedra: '25',
  culebra: '21',
  maja: '21',
  serpiente: '21',
  sapo: '22',
  rana: '22',
  avispa: '27',
  chivo: '28',
  raton: '29',
  camaron: '30',
  venado: '31',
  puerco: '32',
  cochino: '32',
  cerdo: '32',
  aura: '33',
  mono: '34',
  arana: '35',
  sol: '43',
  borracho: '37',
  gallina: '38',
  culebron: '39',
  cura: '05',
  sacerdote: '05',
  dinero: '48',
  plata: '48',
  oro: '90',
  sangre: '63',
  bailarina: '73',
  ladron: '77',
  reina: '88',
  amor: '17',
  fuego: '76',
  buey: '16',
  nino: '81',
  ninos: '81',
  bebe: '81',
  vaca: '92',
  leon: '89',
  tiburon: '70',
  ballena: '85',
  luz: '43',
  estrella: '55',
  cielo: '84',
  diablo: '20',
  iglesia: '05',
  policia: '77',
  carro: '54',
  auto: '54',
  casa: '58',
  muerta: '64',
}

export type DrawResult = {
  date: string
  draw: string
  /** Full Florida Pick 3 number */
  pick3: string
  /** Two digit "bolita" derived from Pick 3 (last two digits) */
  bolita: string
}

// Recent results (Florida Pick 3 model). Bolita = last two digits of the Pick 3.
export const RECENT_RESULTS: DrawResult[] = [
  { date: '20 JUL', draw: 'Florida Noche', pick3: '5-4-8', bolita: '48' },
  { date: '20 JUL', draw: 'Florida Día', pick3: '1-1-5', bolita: '15' },
  { date: '19 JUL', draw: 'Florida Noche', pick3: '9-0-3', bolita: '03' },
  { date: '19 JUL', draw: 'Florida Día', pick3: '7-7-0', bolita: '70' },
  { date: '18 JUL', draw: 'Florida Noche', pick3: '2-8-8', bolita: '88' },
  { date: '18 JUL', draw: 'Florida Día', pick3: '4-3-1', bolita: '31' },
  { date: '17 JUL', draw: 'Florida Noche', pick3: '6-2-4', bolita: '24' },
  { date: '17 JUL', draw: 'Florida Día', pick3: '0-9-9', bolita: '99' },
]

export function normalizeKeyword(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // strip accents
    .replace(/[^a-z]/g, '')
}
