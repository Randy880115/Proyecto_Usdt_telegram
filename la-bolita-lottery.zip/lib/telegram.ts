// Minimal typings + safe accessors for the Telegram WebApp SDK.

type HapticStyle = 'light' | 'medium' | 'heavy' | 'rigid' | 'soft'
type NotificationType = 'error' | 'success' | 'warning'

export type TelegramWebApp = {
  initDataUnsafe?: {
    user?: {
      username?: string
      first_name?: string
      last_name?: string
    }
  }
  expand: () => void
  ready: () => void
  sendData: (data: string) => void
  setHeaderColor?: (color: string) => void
  setBackgroundColor?: (color: string) => void
  HapticFeedback?: {
    impactOccurred: (style: HapticStyle) => void
    notificationOccurred: (type: NotificationType) => void
    selectionChanged: () => void
  }
}

declare global {
  interface Window {
    Telegram?: {
      WebApp?: TelegramWebApp
    }
  }
}

export function getWebApp(): TelegramWebApp | undefined {
  if (typeof window === 'undefined') return undefined
  return window.Telegram?.WebApp
}

export function haptic(style: HapticStyle = 'medium') {
  getWebApp()?.HapticFeedback?.impactOccurred(style)
}

export function notify(type: NotificationType) {
  getWebApp()?.HapticFeedback?.notificationOccurred(type)
}
